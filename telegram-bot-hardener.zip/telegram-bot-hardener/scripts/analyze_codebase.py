#!/usr/bin/env python3
"""
analyze_codebase.py — Analiza un bot de Telegram (aiogram 3) en busca de patrones frágiles.

Uso:
    python analyze_codebase.py <ruta_del_proyecto>
    python analyze_codebase.py .
"""

import ast
import os
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class Issue:
    severity: str  # "CRITICAL", "WARNING", "INFO"
    file: str
    line: Optional[int]
    message: str
    suggestion: str


@dataclass
class AnalysisReport:
    issues: list[Issue] = field(default_factory=list)
    stats: dict = field(default_factory=dict)

    def add(self, severity, file, line, message, suggestion):
        self.issues.append(Issue(severity, file, line, message, suggestion))

    def critical(self):
        return [i for i in self.issues if i.severity == "CRITICAL"]

    def warnings(self):
        return [i for i in self.issues if i.severity == "WARNING"]

    def info(self):
        return [i for i in self.issues if i.severity == "INFO"]


def find_python_files(root: Path) -> list[Path]:
    return [
        p for p in root.rglob("*.py")
        if not any(part in p.parts for part in ["__pycache__", ".venv", "venv", "node_modules"])
    ]


def analyze_file(filepath: Path, report: AnalysisReport):
    rel_path = str(filepath)
    
    try:
        source = filepath.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(filepath))
    except (SyntaxError, UnicodeDecodeError) as e:
        report.add("WARNING", rel_path, None, f"No se pudo parsear: {e}", "Revisar manualmente")
        return

    lines = source.splitlines()

    # ── 1. Funciones muy largas ──────────────────────────────────
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            func_lines = (node.end_lineno or node.lineno) - node.lineno
            if func_lines > 60:
                report.add(
                    "WARNING", rel_path, node.lineno,
                    f"Función '{node.name}' tiene {func_lines} líneas (>60)",
                    "Extraer en sub-funciones o mover lógica a un Service"
                )
            elif func_lines > 40:
                report.add(
                    "INFO", rel_path, node.lineno,
                    f"Función '{node.name}' tiene {func_lines} líneas (>40)",
                    "Considerar dividir si la función hace más de una cosa"
                )

    # ── 2. Except genérico (captura silenciosa) ──────────────────
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            if node.type is None:
                report.add(
                    "CRITICAL", rel_path, node.lineno,
                    "except: sin tipo captura todo silenciosamente",
                    "Usar 'except Exception as e: logger.error(e)' con tipo específico"
                )
            elif isinstance(node.type, ast.Name) and node.type.id == "Exception":
                # Verificar si el cuerpo solo tiene 'pass' o similar
                body_stmts = node.body
                if len(body_stmts) == 1 and isinstance(body_stmts[0], ast.Pass):
                    report.add(
                        "CRITICAL", rel_path, node.lineno,
                        "except Exception: pass — error silenciado completamente",
                        "Al menos loggear: logger.error('Error en X', exc_info=True)"
                    )

    # ── 3. Variables globales mutables ───────────────────────────
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name):
            value = node.value
            if isinstance(value, (ast.Dict, ast.List, ast.Set)):
                name = node.targets[0].id
                if not name.startswith("_") and name.isupper() is False:
                    # Es global mutable no constante
                    parent_is_function = any(
                        isinstance(p, (ast.FunctionDef, ast.AsyncFunctionDef))
                        for p in ast.walk(tree)
                        if hasattr(p, 'body') and node in getattr(p, 'body', [])
                    )
                    # Solo reportar si está al nivel de módulo
                    report.add(
                        "WARNING", rel_path, node.lineno,
                        f"Variable global mutable '{name}' (dict/list/set al nivel de módulo)",
                        "Encapsular en clase o pasar como dependencia para evitar estado compartido"
                    )

    # ── 4. Lógica de negocio en handlers aiogram ─────────────────
    aiogram_handler_decorators = {"message_handler", "callback_query_handler", "router"}
    
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Buscar funciones con parámetros típicos de handlers (message, callback, call)
            param_names = [arg.arg for arg in node.args.args]
            is_handler = any(p in ("message", "callback", "call", "query", "event") for p in param_names)
            
            if is_handler:
                func_lines = (node.end_lineno or node.lineno) - node.lineno
                if func_lines > 20:
                    report.add(
                        "WARNING", rel_path, node.lineno,
                        f"Handler '{node.name}' ({func_lines} líneas) contiene probablemente lógica de negocio",
                        "Mover la lógica a un Service; el handler debe tener <15 líneas"
                    )

    # ── 5. Imports entre módulos del mismo sistema (acoplamiento) ─
    known_modules = ["gamification", "narrative", "channel_admin", "minigame"]
    imports_found = []
    
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            module = ""
            if isinstance(node, ast.ImportFrom) and node.module:
                module = node.module
            elif isinstance(node, ast.Import):
                module = ", ".join(alias.name for alias in node.names)
            
            for mod in known_modules:
                if mod in module and mod not in rel_path:
                    imports_found.append((node.lineno, module))

    if len(imports_found) > 2:
        for lineno, module in imports_found:
            report.add(
                "WARNING", rel_path, lineno,
                f"Import cruzado de '{module}' desde módulo diferente",
                "Usar Event Bus o inyección de dependencias en vez de imports directos"
            )

    # ── 6. Ausencia de type hints en funciones públicas ──────────
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name.startswith("_"):
                continue
            has_return_hint = node.returns is not None
            args_without_hints = [
                arg.arg for arg in node.args.args
                if arg.annotation is None and arg.arg != "self"
            ]
            if not has_return_hint or args_without_hints:
                report.add(
                    "INFO", rel_path, node.lineno,
                    f"Función '{node.name}' sin type hints completos",
                    "Agregar type hints mejora la detectabilidad de bugs y la legibilidad"
                )

    # ── 7. Detección de TODOs y FIXMEs ───────────────────────────
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        if stripped.startswith("#"):
            upper = stripped.upper()
            if "TODO" in upper or "FIXME" in upper or "HACK" in upper:
                report.add(
                    "INFO", rel_path, i,
                    f"Deuda técnica marcada: {stripped[:80]}",
                    "Revisar y crear ticket o issue para no perder track"
                )


def detect_circular_imports(files: list[Path], root: Path) -> list[tuple]:
    """Detecta posibles imports circulares entre módulos."""
    import_graph: dict[str, set[str]] = {}
    
    for filepath in files:
        rel = str(filepath.relative_to(root)).replace("/", ".").replace(".py", "")
        import_graph[rel] = set()
        
        try:
            source = filepath.read_text(encoding="utf-8")
            tree = ast.parse(source)
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom) and node.module:
                    # Normalizar a path relativo si es posible
                    mod = node.module
                    import_graph[rel].add(mod)
        except Exception:
            pass
    
    # Detección simple de ciclos directos A → B → A
    cycles = []
    for mod_a, deps_a in import_graph.items():
        for mod_b in deps_a:
            if mod_b in import_graph and mod_a in import_graph.get(mod_b, set()):
                pair = tuple(sorted([mod_a, mod_b]))
                if pair not in cycles:
                    cycles.append(pair)
    
    return cycles


def print_report(report: AnalysisReport, root: Path):
    print("\n" + "="*70)
    print("  REPORTE DE ANÁLISIS — Telegram Bot Hardener")
    print("="*70)

    print(f"\n📊 Archivos analizados: {report.stats.get('files', 0)}")
    print(f"   🔴 Críticos:  {len(report.critical())}")
    print(f"   🟡 Warnings:  {len(report.warnings())}")
    print(f"   🔵 Info:      {len(report.info())}")

    if report.critical():
        print("\n" + "─"*70)
        print("🔴 CRÍTICOS — Resolver antes de cualquier cambio")
        print("─"*70)
        for issue in report.critical():
            loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
            print(f"\n  [{loc}]")
            print(f"  Problema:   {issue.message}")
            print(f"  Solución:   {issue.suggestion}")

    if report.warnings():
        print("\n" + "─"*70)
        print("🟡 WARNINGS — Fragilidad potencial")
        print("─"*70)
        for issue in report.warnings():
            loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
            print(f"\n  [{loc}]")
            print(f"  Problema:   {issue.message}")
            print(f"  Solución:   {issue.suggestion}")

    if report.info():
        print("\n" + "─"*70)
        print("🔵 INFO — Deuda técnica y mejoras")
        print("─"*70)
        for issue in report.info():
            loc = f"{issue.file}:{issue.line}" if issue.line else issue.file
            print(f"  [{loc}] {issue.message}")

    print("\n" + "="*70)
    print("  PRÓXIMOS PASOS RECOMENDADOS")
    print("="*70)
    
    if report.critical():
        print("\n  Semana 1 (crítico):")
        print("  - Agregar middleware de error global (ver references/architecture-patterns.md §3)")
        print("  - Eliminar todos los 'except: pass' — cada uno es un bug oculto")
    
    print("\n  Semana 2 (estructura):")
    print("  - Separar lógica de negocio de handlers → Service Layer")
    print("  - Crear repositorios para acceso a datos")
    
    print("\n  Semana 3 (tests):")
    print("  - Configurar pytest + pytest-asyncio")
    print("  - Crear tests/conftest.py con fixtures base")
    print("  - Tests unitarios de los servicios creados en semana 2")
    
    print()


def main():
    if len(sys.argv) < 2:
        print("Uso: python analyze_codebase.py <ruta_del_proyecto>")
        sys.exit(1)

    root = Path(sys.argv[1]).resolve()
    if not root.exists():
        print(f"Error: La ruta '{root}' no existe.")
        sys.exit(1)

    print(f"\n🔍 Analizando: {root}")
    
    files = find_python_files(root)
    report = AnalysisReport()
    report.stats["files"] = len(files)

    for filepath in files:
        analyze_file(filepath, report)

    # Detección de imports circulares
    cycles = detect_circular_imports(files, root)
    if cycles:
        for cycle in cycles:
            report.add(
                "CRITICAL", f"{cycle[0]} ↔ {cycle[1]}", None,
                f"Posible import circular entre módulos: {cycle[0]} y {cycle[1]}",
                "Usar Event Bus o inyección de dependencias para romper el ciclo"
            )

    print_report(report, root)


if __name__ == "__main__":
    main()
